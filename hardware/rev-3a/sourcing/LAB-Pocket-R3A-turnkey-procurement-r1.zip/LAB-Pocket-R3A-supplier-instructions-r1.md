# LAB Pocket Rev 3A prototype assembly inquiry · revision 1

Please assess one fully populated LAB Pocket prototype using the enclosed Rev 3A fabrication package dated November 27, 2026. We can take two populated boards if your process requires two. Please specify your minimum and price any extra starts separately. This package is for procurement and DFM review. Production release requires a purchase order.

## Processor and purchasing

We need the assembler to source and place the exact bare Espressif ESP32-P4NRW32X at U1 within one assembly order. Please give the available traceable quantity, supplier, lot/date-code documentation or manufacturer packing label, earliest assembly start, and estimated dispatch date. Please distinguish chips physically available to allocate from expected distributor receipts. A traceable partial reel or cut tape is acceptable if your assembly team accepts the packaging.

Our firmware target and PCB use the X-suffix 32 MB device. Any change of part number, memory capacity, module footprint or board layout needs design review before approval. Please include normal feeder loss and placement minimums in your materials calculation.

Potential supply contacts for U1 include Wireless-Tag, an Espressif-listed distributor and manufacturer of products using the 32 MB v3.2 processor, and Espressif's official sample channel. Their public pages do not establish that loose chips are available for this job. [Wireless-Tag](https://www.espressif.com/en/node/9899) · [Manufacturer's ordering page](https://www.espressif.com/en/products/socs)

## Other materials worth checking early

| Ref | Qty per board | Exact MPN | Procurement lead |
|---|---:|---|---|
| J7 | 1 | DF37NC-30DS-0.4V(51) | [HQ Online](https://www.hqonline.com/product-detail/board-to-board-connectors-hrs-df37nc-30ds-0-4v-51--2500328192) |
| U22 | 1 | APS6404L-3SQR-SN | [HQ Online](https://www.hqonline.com/product-detail/other-memories-apmemory-aps6404l-3sqr-sn-2500439770) |
| U25, U26 | 2 | TLV75528PDBVR | [DigiKey](https://www.digikey.com/en/products/detail/texas-instruments/TLV75528PDBVR/9356538) |
| C67 | 1 | C0805C226M9PACTU | The public JLC count was four, below its catalog placement minimum of five. Please source the exact part or propose a comparable 0805 capacitor with DC-bias data for engineering approval. [KEMET ordering reference](https://www.digikey.com/en/products/detail/kemet/C0805C226M9PACTU/992189) |
| Y3 | 1 | ASDMB-24.000MHZ-LY-T | Public JLC stock was three. Include setup allowance for your process. |

## Scope and design files

The turnkey BOM lists manufacturer names, part numbers, quantities per populated board and reference designators for 357 placements across both sides. The JLC BOM is also provided for part cross-references. The CPL contains placement positions and rotations. Validate the bottom-side convention, origin, pin 1, switch orientation and LED polarity against the enclosed schematic and Gerbers.

The enclosed stackup specifies an eight-layer, nominal 1.6 mm ENIG board, controlled impedances, and 0.15 mm finished drilled, filled and capped vias. Please identify your proposed stack, impedance results and any fabrication exceptions before production. The Gerber ZIP includes the drill files.

Please price procurement or installation of the non-SMT assemblies as separate lines in the same order if offered. The panel is Tailor Pixels TTC273XSI-01. The camera is Seeed 114992267. The full project parts list and battery-harness instructions identify the Jauch protected pack, NTC, harness, adhesives and removable storage. Identify which items can be supplied in the same shipment, which can be installed, and any unavailable items. Separate the tested PCBA scope from firmware loading, optical alignment and complete-device functional test.

Design baseline e3854ad621fa209e67dc9eebed1f16f999367198. This is the first physical prototype. Please identify assembly inspection coverage and any test fixture or programming image you require.
